
function processSubmit(e) { 
    e.preventDefault(); 
    const firstnameInForm = document.querySelector("#firstname1").value; 
    const lastnameInForm = document.querySelector("#lastname1").value; 
    const emailInForm = document.querySelector("#email1").value; 
    const messageInForm = document.querySelector("#comment1").value; 
    
    const form = document.querySelector("#dataCapture"); 

    form.addEventListener("submit", processSubmit);

    function onTextReady(text){
        const areaOfText = document.getElementById("text-area");
        areaOfText.style.cssText = "color:red"
        // areaOfText.append(text); 
        console.log(text); 
        
    }

    
    function onResponse(response){
        return response.text();
        
    }
    
    const message = {
        name: firstnameInForm,
        lastName: lastnameInForm,
        email: emailInForm,
        message: messageInForm
    };
    
    const serializedMessage = JSON.stringify(message);
    
    const fetchOptions = {
        method: "POST",
        headers:{
            "Accept": "application/json",
            "Content-Type":"application/json"
        },
        body: serializedMessage
    }
    
    fetch("http://localhost:4040/form", fetchOptions)
    .then(onResponse)
    .then(onTextReady);
}

window.addEventListener("DOMContentLoaded", processSubmit, false);

const captureData = document.querySelector("dataCapture");
const submit = document.querySelector("#submitplease");
submit.addEventListener("click", processSubmit)