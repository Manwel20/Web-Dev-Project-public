// fetch("")


// class Goal2{
//     constructor(){
        
//     }
// }

// const goal2Content = new Goal2();

// const array = [];

// array.push(goal2Content);


// console.log(array.length);

// array.map((item)=>{
//     console.log(`item ${item.desc}`);
// })

// const sectionCenter = document.querySelector("#section-info5");


// function loadContent(){
//     let displayItem = array.map((item) => {
//         return `
//               <div>
//                 <form method="post" action="" id = "dataCapture">
//                     <fieldset>
//                         <legend>Sign up<i class="fa-solid fa-users"></i></legend>
//                         <label for="First name">First name*</label>
//                         <input type="text" id="firstname1" name="myname" placeholder="First name" required>
//                         <label for="last name">Last name*</label>
//                         <input type="text" id="lastname1" name="myname" placeholder="Last name" required>
//                         <label for="email">Email address*<i class="fa-solid fa-users"></i></label>
//                         <input type="text" id="email1" name="emailaddress" placeholder="Email" required>
//                         <label for="message">Which goal are you interested in?<i class="fa-solid fa-users"></i></label>
//                         <textarea id="comment1" name="message1" rows="5" cols="33" placeholder="Write comment here and submit" required></textarea>
//                         <input type="submit" id="submitplease" value="Send"/>
//                         <div id = "text-area"></div>
//                     </fieldset>
//                     </form> 
//                </div>
        
//         `
        
//     })

//     displayItem = displayItem.join("");
//     sectionCenter.innerHTML = displayItem;
// }


// function processSubmit(e) { 

//     e.preventDefault(); 
//     // Get values from form fields 

//     const firstnameInForm = document.querySelector("#firstname1").value; 

//     const lastnameInForm = document.querySelector("#lastname1").value; 

//     const emailInForm = document.querySelector("#email1").value; 

//     const messageInForm = document.querySelector("#comment1").value; 

    
//     // Display values in the console 

//     console.log("First Name:", firstnameInForm); 

//     console.log("Last Name:", lastnameInForm); 

//     console.log("Email:", emailInForm); 

//     console.log("Message:", messageInForm);
    
//     const form = document.querySelector("#dataCapture"); 

//     form.addEventListener("submit", processSubmit);

// }
// window.addEventListener("DOMContentLoaded", loadContent, false);


