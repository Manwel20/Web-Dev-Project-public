const express = require("express")
const app = express();
const port = 4040;

const bodyParser = require("body-parser");
const jsonParser = bodyParser.json();

app.use(express.static("public"));


app.get("/",(req, res) => {
    res.sendFile("index.html",(err) =>{
        if (err){
            console.log(err)
        }
    })
});

app.get("/signup.html",(req, res) => {
    res.sendFile("signup.html",(err) =>{
        if (err){
            console.log(err)
        }
    })
});


app.post("/form", jsonParser, (req,res) =>{
    const body = req.body;
    const name = body.name;
    const lastName = body.lastName;
    const email = body.email;
    const message = body.message;
    if(!name || !lastName || !email || !message) {
        res.send(`Please enter details: `);
    } else {
        res.send(`POST by signupClear.js - name = ${name}   , last Name = ${lastName}, email = ${email}  , message = ${message}  `);
    }   
});




app.listen(port, () =>{
    console.log(`My first app listening on port ${port}!`)
});